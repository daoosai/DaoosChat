function e(t){return Object.prototype.toString.call(t).slice(8,-1).toLowerCase()==="object"}export{e as i};
//# sourceMappingURL=helpers-DWHPOMuB.js.map
