const t="",E={INCOMING:0,OUTGOING:1,ACTIVITY:2,TEMPLATE:3},T="chatwoot-widget:";export{t as A,E as M,T as W};
//# sourceMappingURL=constants-lVAyZKq6.js.map
